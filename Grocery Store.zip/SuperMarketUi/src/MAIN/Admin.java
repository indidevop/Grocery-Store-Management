package MAIN;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;

import com.store.dbrepository.CRUDRepository;
import com.store.entities.StockDetails;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

public class Admin extends JFrame {

	private JPanel contentPane;
	private JTextField PID_field;
	private JTextField Pname_field;
	private JTextField Quantity_field;
	private JTextField Price_field;
	private CRUDRepository crudrepo;
	private JTextField txtSearch;
	private JTable details;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		
		crudrepo=new CRUDRepository();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1091, 616);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel left_panel = new JPanel();
		left_panel.setBorder(null);
		left_panel.setBounds(0, 0, 562, 579);
		contentPane.add(left_panel);
		left_panel.setLayout(null);
		
		JLabel Price_label = new JLabel("Price per kg");
		Price_label.setForeground(new Color(75, 0, 130));
		Price_label.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		Price_label.setBounds(41, 298, 86, 14);
		left_panel.add(Price_label);
		
		JLabel Quantity_label = new JLabel("Quantity");
		Quantity_label.setForeground(new Color(75, 0, 130));
		Quantity_label.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		Quantity_label.setBounds(41, 229, 86, 14);
		left_panel.add(Quantity_label);
		
		JLabel name_label = new JLabel("Product name");
		name_label.setForeground(new Color(75, 0, 130));
		name_label.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		name_label.setBounds(41, 162, 96, 14);
		left_panel.add(name_label);
		
		JLabel ID_label = new JLabel("Product ID");
		ID_label.setForeground(new Color(75, 0, 130));
		ID_label.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		ID_label.setBounds(41, 97, 86, 14);
		left_panel.add(ID_label);
		
		PID_field = new JTextField();
		PID_field.setHorizontalAlignment(SwingConstants.CENTER);
		PID_field.setColumns(10);
		PID_field.setBounds(147, 85, 316, 37);
		left_panel.add(PID_field);
		
		Pname_field = new JTextField();
		Pname_field.setHorizontalAlignment(SwingConstants.CENTER);
		Pname_field.setColumns(10);
		Pname_field.setBounds(147, 150, 316, 37);
		left_panel.add(Pname_field);
		
		Quantity_field = new JTextField();
		Quantity_field.setHorizontalAlignment(SwingConstants.CENTER);
		Quantity_field.setColumns(10);
		Quantity_field.setBounds(147, 217, 316, 37);
		left_panel.add(Quantity_field);
		
		Price_field = new JTextField();
		Price_field.setHorizontalAlignment(SwingConstants.CENTER);
		Price_field.setColumns(10);
		Price_field.setBounds(147, 286, 316, 37);
		left_panel.add(Price_field);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setFocusable(false);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddStock();
				loadtablAdmin();
			}
		});
		btnAdd.setForeground(new Color(75, 0, 130));
		btnAdd.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnAdd.setBackground(Color.WHITE);
		btnAdd.setBounds(95, 365, 99, 37);
		left_panel.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFocusable(false);
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateStock();
				loadtablAdmin();
			}
		});
		btnUpdate.setForeground(new Color(75, 0, 130));
		btnUpdate.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnUpdate.setBackground(Color.WHITE);
		btnUpdate.setBounds(231, 365, 99, 37);
		left_panel.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFocusable(false);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteStock();
				loadtablAdmin();
			}
		});
		btnDelete.setForeground(new Color(75, 0, 130));
		btnDelete.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnDelete.setBackground(Color.WHITE);
		btnDelete.setBounds(364, 365, 99, 37);
		left_panel.add(btnDelete);
		
		JLabel TopLabel = new JLabel("Admin View");
		TopLabel.setForeground(new Color(178, 34, 34));
		TopLabel.setFont(new Font("Times New Roman", Font.BOLD, 17));
		TopLabel.setHorizontalAlignment(SwingConstants.CENTER);
		TopLabel.setBounds(204, 11, 154, 51);
		left_panel.add(TopLabel);
		
		txtSearch = new JTextField();
		txtSearch.setHorizontalAlignment(SwingConstants.CENTER);
		txtSearch.setColumns(10);
		txtSearch.setBounds(183, 458, 198, 37);
		left_panel.add(txtSearch);
		
		JLabel ID_label_1 = new JLabel("Search using ID");
		ID_label_1.setForeground(new Color(75, 0, 130));
		ID_label_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		ID_label_1.setBounds(55, 470, 119, 14);
		left_panel.add(ID_label_1);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setFocusable(false);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchStock();
			}
		});
		btnSearch.setForeground(new Color(75, 0, 130));
		btnSearch.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnSearch.setBackground(Color.WHITE);
		btnSearch.setBounds(407, 456, 99, 37);
		left_panel.add(btnSearch);
		
		JButton btnDone = new JButton("Ok");
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				HomeUI h2=new HomeUI();
				h2.setVisible(true);
				close();
			}
		});
		btnDone.setForeground(new Color(75, 0, 130));
		btnDone.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnDone.setFocusable(false);
		btnDone.setBackground(Color.WHITE);
		btnDone.setBounds(321, 515, 99, 37);
		left_panel.add(btnDone);
		
		JButton btnOrderHistory = new JButton("Order History");
		btnOrderHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				History h1=new History();
				h1.loadtable();
				h1.setVisible(true);
			}
		});
		btnOrderHistory.setForeground(new Color(75, 0, 130));
		btnOrderHistory.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnOrderHistory.setFocusable(false);
		btnOrderHistory.setBackground(Color.WHITE);
		btnOrderHistory.setBounds(119, 515, 161, 37);
		left_panel.add(btnOrderHistory);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		scrollPane.setBounds(572, 11, 495, 557);
		contentPane.add(scrollPane);
		
		details = new JTable();
		scrollPane.setViewportView(details);
	}
	public void AddStock()
	{
		String idstring = PID_field.getText();
		int id = Integer.parseInt(idstring);
		String name = Pname_field.getText();
		String qtystr = Quantity_field.getText();
		int qty = Integer.parseInt(qtystr);
		String Pricestr = Price_field.getText();
		int price = Integer.parseInt(Pricestr);
		StockDetails stk = new StockDetails(id,name,qty,price);
		crudrepo.addStock(stk);
	}
	
	public void updateStock()
	{
		String idstring = PID_field.getText();
		int id = Integer.parseInt(idstring);
		String name = Pname_field.getText();
		String qtystr = Quantity_field.getText();
		int qty = Integer.parseInt(qtystr);
		String Pricestr = Price_field.getText();
		int price = Integer.parseInt(Pricestr);
		StockDetails stk = new StockDetails(id,name,qty,price);
		crudrepo.updateStock(stk);
	}
	public void searchStock()
	{
		String idstr = txtSearch.getText();
		int id = Integer.parseInt(idstr);
		StockDetails stk = crudrepo.getStock(id);
		PID_field.setText(String.valueOf(stk.getProduct_no()));
		Pname_field.setText(stk.getProduct_name());
		Quantity_field.setText(String.valueOf(stk.getQuantity()));
		Price_field.setText(String.valueOf(stk.getPrice_per_kg()));
	}
	
	public void deleteStock()
	{
		String idstring = PID_field.getText();
		int id = Integer.parseInt(idstring);
		crudrepo.deleteStock(id);
	}
	public void loadtablAdmin()
	{
		ResultSet resultSet=crudrepo.getStock();
		details.setModel(DbUtils.resultSetToTableModel(resultSet));
	}
	public void close()
	{
		WindowEvent closewindow=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closewindow);
	}
}
