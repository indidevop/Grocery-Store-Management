package MAIN;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

import com.store.dbrepository.CRUDRepository;
import com.store.entities.Cart;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

import java.time.LocalDate;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;
import javax.swing.JScrollPane;  
    
   
         
      
  
public class Bill extends JFrame {
	int ID;
	String name;
	String adr;
	String formattedDate;
	private CRUDRepository crudrepo;
	private JPanel contentPane;
	private JTable billTable;
	private JTextField cnameField;
	private JTextField cidField;
	private JTextField dateField;
	private JTextField textAddress;
	private JTextField totalField;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bill frame = new Bill();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bill() {
		crudrepo=new CRUDRepository();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 675, 660);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCheckout = new JButton("Close");
		btnCheckout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close();
				HomeUI h1=new HomeUI();
				h1.setVisible(true);
			}
		});
		btnCheckout.setFocusable(false);
		btnCheckout.setBounds(287, 579, 96, 31);
		btnCheckout.setForeground(new Color(75, 0, 130));
		btnCheckout.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnCheckout.setBackground(Color.WHITE);
		contentPane.add(btnCheckout);
		
		JLabel lblNewLabel = new JLabel("INVOICE");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(230, 11, 202, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer name");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(43, 57, 96, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Customer ID");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1_1.setBounds(43, 93, 96, 25);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Date ");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1_1_1.setBounds(488, 57, 35, 25);
		contentPane.add(lblNewLabel_1_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(40, 188, 578, 380);
		contentPane.add(scrollPane);
		
		billTable = new JTable();
		scrollPane.setViewportView(billTable);
		billTable.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		
		cnameField = new JTextField();
		cnameField.setFocusTraversalKeysEnabled(false);
		cnameField.setFocusable(false);
		cnameField.setBackground(new Color(245, 255, 250));
		cnameField.setBounds(159, 59, 273, 20);
		contentPane.add(cnameField);
		cnameField.setColumns(10);
		
		cidField = new JTextField();
		cidField.setEditable(false);
		cidField.setFocusTraversalKeysEnabled(false);
		cidField.setFocusable(false);
		cidField.setBackground(new Color(245, 255, 250));
		cidField.setColumns(10);
		cidField.setBounds(159, 95, 273, 20);
		contentPane.add(cidField);
		
		dateField = new JTextField();
		dateField.setFocusTraversalKeysEnabled(false);
		dateField.setFocusable(false);
		dateField.setBackground(new Color(245, 255, 250));
		dateField.setEditable(false);
		dateField.setColumns(10);
		dateField.setBounds(522, 59, 96, 20);
		contentPane.add(dateField);
		
		JLabel lblNewLabel_1_2 = new JLabel("Shipping Address");
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1_2.setBounds(43, 129, 96, 25);
		contentPane.add(lblNewLabel_1_2);
		
		textAddress = new JTextField();
		textAddress.setFocusable(false);
		textAddress.setFocusTraversalKeysEnabled(false);
		textAddress.setEditable(false);
		textAddress.setColumns(10);
		textAddress.setBackground(new Color(245, 255, 250));
		textAddress.setBounds(159, 131, 273, 39);
		contentPane.add(textAddress);
		
		totalField = new JTextField();
		totalField.setFocusable(false);
		totalField.setFocusTraversalKeysEnabled(false);
		totalField.setEditable(false);
		totalField.setColumns(10);
		totalField.setBackground(new Color(245, 255, 250));
		totalField.setBounds(522, 579, 96, 20);
		contentPane.add(totalField);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Total");
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1_1_1_1.setBounds(488, 579, 35, 25);
		contentPane.add(lblNewLabel_1_1_1_1);
	}
	
	
	
	public void close()
	{
		WindowEvent closewindow=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closewindow);
	}
	
	public void loadtable()
	{
		ResultSet resultSet=crudrepo.getCart();
		billTable.setModel(DbUtils.resultSetToTableModel(resultSet));
	}
	public void getid(int id)
	{
		ID=id;
		getEverything();
	}
	
	public void getEverything()
	{
		name=crudrepo.getCustomerName(ID);
		adr=crudrepo.getCustomerAddress(ID);
		LocalDate dt = java.time.LocalDate.now();
		formattedDate = dt.format(DateTimeFormatter.ofPattern("dd-MMM-yy"));
	}
	public void setField(int total)
	{
		cnameField.setText(name);
		cidField.setText(String.valueOf(ID));		
		textAddress.setText(adr);
		dateField.setText(formattedDate);
		totalField.setText(String.valueOf(total));
	}
}