package MAIN;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;

import com.store.dbrepository.CRUDRepository;
import com.store.entities.LoginDetails;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

import javax.swing.Action;
import javax.swing.JPasswordField;

public class HomeUI extends JFrame {
	private CRUDRepository crudrepo;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField UnametextField;
	private JPasswordField PasstextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeUI frame = new HomeUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomeUI() {
		crudrepo=new CRUDRepository();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1091, 616);
		getContentPane().setLayout(null);
		
		JPanel MainPanel = new JPanel();
		MainPanel.setBackground(SystemColor.menu);
		MainPanel.setBounds(0, 0, 1077, 579);
		getContentPane().add(MainPanel);
		MainPanel.setLayout(null);
		
		JPanel Leftpanel = new JPanel();
		Leftpanel.setBounds(0, 0, 368, 579);
		Leftpanel.setBackground(new Color(75, 0, 130));
		MainPanel.add(Leftpanel);
		Leftpanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Amey Sawalkar\\Downloads\\cart-54-256.png"));
		lblNewLabel.setBounds(51, 79, 256, 265);
		Leftpanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ShopEasy");
		lblNewLabel_1.setBounds(91, 379, 178, 74);
		Leftpanel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(new Color(240, 248, 255));
		lblNewLabel_1.setFont(new Font("Showcard Gothic", Font.PLAIN, 28));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_2 = new JLabel("Welcome !");
		lblNewLabel_2.setBounds(632, 75, 203, 52);
		lblNewLabel_2.setFont(new Font("Papyrus", Font.BOLD, 25));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		MainPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("USERNAME");
		lblNewLabel_3.setBounds(567, 168, 86, 14);
		lblNewLabel_3.setForeground(new Color(75, 0, 130));
		lblNewLabel_3.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		MainPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("PASSWORD");
		lblNewLabel_3_1.setBounds(567, 293, 86, 14);
		lblNewLabel_3_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		MainPanel.add(lblNewLabel_3_1);
		
		UnametextField = new JTextField();
		UnametextField.setHorizontalAlignment(SwingConstants.CENTER);
		UnametextField.setBounds(567, 193, 320, 37);
		MainPanel.add(UnametextField);
		UnametextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Sign In");
		btnNewButton.setFocusable(false);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				checkCustomer();
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(new Color(75, 0, 130));
		btnNewButton.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnNewButton.setBounds(597, 398, 99, 37);
		MainPanel.add(btnNewButton);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.setFocusable(false);
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close();
				SignUp s1=new SignUp();
				s1.setVisible(true);
			}
		});
		
		btnSignUp.setBackground(new Color(255, 255, 255));
		
		btnSignUp.setForeground(new Color(75, 0, 130));
		btnSignUp.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnSignUp.setBounds(751, 398, 99, 37);
		MainPanel.add(btnSignUp);
		
		PasstextField = new JPasswordField();
		PasstextField.setHorizontalAlignment(SwingConstants.CENTER);
		PasstextField.setBounds(567, 318, 320, 37);
		MainPanel.add(PasstextField);
		
		JButton AdminBtn = new JButton("Admin login");
		AdminBtn.setFocusable(false);
		AdminBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminCheck();
			}
		});
		AdminBtn.setForeground(new Color(220, 20, 60));
		AdminBtn.setFont(new Font("Tw Cen MT", Font.PLAIN, 19));
		AdminBtn.setBackground(SystemColor.menu);
		AdminBtn.setBounds(938, 537, 129, 31);
		MainPanel.add(AdminBtn);
	}
	
	public void close()
	{
		WindowEvent closewindow=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closewindow);
	}
	
	private void checkCustomer()
	{
		String username=UnametextField.getText();
		String password=PasstextField.getText();
		String admin="admin";
		boolean compareAdmin = username.matches(admin);
		int flag=crudrepo.getCustomer(username, password);
		
		if((flag==1 && compareAdmin) || flag==0)
		{
			close();
			CredCheck cc=new CredCheck();
			cc.setVisible(true);
		}
		if(flag!=0 && !compareAdmin)
		{
			close();
			User s2 = new User();
			s2.getID(flag);
			s2.setVisible(true);
			s2.loadtable();
			s2.loadtableCart();
		}
	}
	private void adminCheck()
	{
		String username=UnametextField.getText();
		String password=PasstextField.getText();
		String admin="admin";
		boolean compareAdmin = username.matches(admin);
		int flag=crudrepo.getCustomer(username, password);
		if(flag==1 && compareAdmin)
		{
			close();
			 Admin s1=new Admin();
			 s1.loadtablAdmin();
			s1.setVisible(true);
		}
		else
		{
			close();
			CredCheck cc=new CredCheck();
			cc.setVisible(true);
		}
	}

	}

