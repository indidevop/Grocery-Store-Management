package MAIN;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.store.dbrepository.CRUDRepository;
import com.store.entities.AddressDetails;
import com.store.entities.CustomerDetails;
import com.store.entities.LoginDetails;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JPasswordField;

public class SignUp extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textName;
	private JTextField textNumber;
	private JTextField textEmail;
	private JTextField textAddress;
	private JTextField textUname;
    private CRUDRepository crudrepo;
    private JPasswordField textPassword;
    private JTextField Pinfield;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		crudrepo=new CRUDRepository();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1102, 608);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel MainPanel = new JPanel();
		MainPanel.setLayout(null);
		MainPanel.setBackground(SystemColor.menu);
		MainPanel.setBounds(0, 0, 1088, 571);
		contentPane.add(MainPanel);
		
		JPanel Leftpanel = new JPanel();
		Leftpanel.setLayout(null);
		Leftpanel.setBackground(new Color(75, 0, 130));
		Leftpanel.setBounds(0, 0, 368, 579);
		MainPanel.add(Leftpanel);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Amey Sawalkar\\Downloads\\cart-54-256.png"));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(51, 79, 256, 265);
		Leftpanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ShopEasy");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(240, 248, 255));
		lblNewLabel_1.setFont(new Font("Showcard Gothic", Font.PLAIN, 28));
		lblNewLabel_1.setBounds(91, 379, 178, 74);
		Leftpanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Name:");
		lblNewLabel_3.setForeground(new Color(75, 0, 130));
		lblNewLabel_3.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(567, 29, 86, 14);
		MainPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Contact Number:");
		lblNewLabel_3_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_1.setBounds(567, 175, 118, 14);
		MainPanel.add(lblNewLabel_3_1);
		
		textName = new JTextField();
		textName.setHorizontalAlignment(SwingConstants.CENTER);
		textName.setColumns(10);
		textName.setBounds(567, 54, 320, 37);
		MainPanel.add(textName);
		
		textNumber = new JTextField();
		textNumber.setHorizontalAlignment(SwingConstants.CENTER);
		textNumber.setColumns(10);
		textNumber.setBounds(567, 200, 320, 37);
		MainPanel.add(textNumber);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				saveDetails();				
				close();
				Acknowledgement s1=new Acknowledgement();
				s1.setVisible(true);
				
			}
		});
		btnSignUp.setForeground(new Color(75, 0, 130));
		btnSignUp.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnSignUp.setBackground(Color.WHITE);
		btnSignUp.setBounds(669, 523, 99, 37);
		MainPanel.add(btnSignUp);
		
		JLabel lblNewLabel_3_2 = new JLabel("Email:");
		lblNewLabel_3_2.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_2.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_2.setBounds(567, 102, 86, 14);
		MainPanel.add(lblNewLabel_3_2);
		
		textEmail = new JTextField();
		textEmail.setHorizontalAlignment(SwingConstants.CENTER);
		textEmail.setColumns(10);
		textEmail.setBounds(567, 127, 320, 37);
		MainPanel.add(textEmail);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Address:");
		lblNewLabel_3_2_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_2_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_2_1.setBounds(567, 248, 86, 14);
		MainPanel.add(lblNewLabel_3_2_1);
		
		textAddress = new JTextField();
		textAddress.setHorizontalAlignment(SwingConstants.CENTER);
		textAddress.setColumns(10);
		textAddress.setBounds(567, 267, 320, 37);
		MainPanel.add(textAddress);
		
		JLabel lblNewLabel_3_2_1_1 = new JLabel("Username:");
		lblNewLabel_3_2_1_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_2_1_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_2_1_1.setBounds(567, 385, 86, 14);
		MainPanel.add(lblNewLabel_3_2_1_1);
		
		textUname = new JTextField();
		textUname.setHorizontalAlignment(SwingConstants.CENTER);
		textUname.setColumns(10);
		textUname.setBounds(567, 402, 320, 37);
		MainPanel.add(textUname);
		
		JLabel lblNewLabel_3_2_1_1_1 = new JLabel("Password:");
		lblNewLabel_3_2_1_1_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_2_1_1_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_2_1_1_1.setBounds(567, 450, 86, 14);
		MainPanel.add(lblNewLabel_3_2_1_1_1);
		
		textPassword = new JPasswordField();
		textPassword.setHorizontalAlignment(SwingConstants.CENTER);
		textPassword.setBounds(567, 475, 320, 37);
		MainPanel.add(textPassword);
		
		Pinfield = new JTextField();
		Pinfield.setHorizontalAlignment(SwingConstants.CENTER);
		Pinfield.setColumns(10);
		Pinfield.setBounds(567, 335, 320, 37);
		MainPanel.add(Pinfield);
		
		JLabel lblNewLabel_3_2_1_1_1_1 = new JLabel("Pin Code");
		lblNewLabel_3_2_1_1_1_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_2_1_1_1_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_2_1_1_1_1.setBounds(567, 315, 86, 14);
		MainPanel.add(lblNewLabel_3_2_1_1_1_1);
	}
	public void close()
	{
		WindowEvent closewindow=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closewindow);
	}
	
	private void saveDetails()
	{
		String name=textName.getText();
		String mail=textEmail.getText();
	    String contactStr=textNumber.getText();
	    int contact=Integer.parseInt(contactStr);
	    String address=textAddress.getText();
	    String username=textUname.getText();
	    String pass=textPassword.getText();
	    String pincodestr=Pinfield.getText();
	    int pincode=Integer.parseInt(pincodestr);

	    CustomerDetails cust = new CustomerDetails(name,mail,contact);
		AddressDetails addr = new AddressDetails(address,pincode);
		LoginDetails login = new LoginDetails(username,pass);
		crudrepo.addCustomer(cust,addr,login);
	}
}
