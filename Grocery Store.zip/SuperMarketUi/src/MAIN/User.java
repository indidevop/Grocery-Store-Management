package MAIN;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.store.dbrepository.CRUDRepository;
import com.store.entities.Cart;
import com.store.entities.StockDetails;

import net.proteanit.sql.DbUtils;

import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class User extends JFrame {
	private CRUDRepository crudrepo;
	int id;
	int total;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final JPanel FieldPanel = new JPanel();
	private final JTable cart = new JTable();
	private JTable details;
	private JTextField PField;
	private JTextField Qfield;
	private JTextField textSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User frame = new User();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public User() {
		
		crudrepo=new CRUDRepository();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1258, 639);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		FieldPanel.setBorder(null);
		FieldPanel.setBounds(0, 0, 406, 591);
		contentPane.add(FieldPanel);
		FieldPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.setFocusable(false);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddToCart();
				updateStock();
				loadtableCart();
				loadtable();
				
			}
		});
		btnNewButton.setBounds(108, 185, 87, 31);
		btnNewButton.setForeground(new Color(75, 0, 130));
		btnNewButton.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnNewButton.setBackground(Color.WHITE);
		FieldPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Edit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateCart();
				loadtableCart();
				PField.setEditable(true);
				updateStock_edit();
				loadtable();
			}
		});
		btnNewButton_1.setFocusable(false);
		btnNewButton_1.setForeground(new Color(75, 0, 130));
		btnNewButton_1.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(220, 185, 87, 31);
		FieldPanel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Delete");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				deleteCart();
				loadtableCart();
				updateStock_delete();
				loadtable();
			}
		});
		btnNewButton_1_1.setFocusable(false);
		btnNewButton_1_1.setForeground(new Color(75, 0, 130));
		btnNewButton_1_1.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnNewButton_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1.setBounds(97, 420, 87, 31);
		FieldPanel.add(btnNewButton_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("Product Id");
		lblNewLabel_3.setForeground(new Color(75, 0, 130));
		lblNewLabel_3.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(78, 82, 86, 14);
		FieldPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Quantity");
		lblNewLabel_3_1.setForeground(new Color(75, 0, 130));
		lblNewLabel_3_1.setFont(new Font("Bahnschrift", Font.PLAIN, 14));
		lblNewLabel_3_1.setBounds(78, 125, 86, 14);
		FieldPanel.add(lblNewLabel_3_1);
		
		PField = new JTextField();
		PField.setHorizontalAlignment(SwingConstants.CENTER);
		PField.setColumns(10);
		PField.setBounds(174, 78, 154, 20);
		FieldPanel.add(PField);
		
		Qfield = new JTextField();
		Qfield.setHorizontalAlignment(SwingConstants.CENTER);
		Qfield.setColumns(10);
		Qfield.setBounds(174, 121, 154, 20);
		FieldPanel.add(Qfield);
		
		JLabel lblNewLabel = new JLabel("Enter product ID to modify");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setForeground(new Color(178, 34, 34));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(97, 325, 217, 31);
		FieldPanel.add(lblNewLabel);
		
		textSearch = new JTextField();
		textSearch.setHorizontalAlignment(SwingConstants.CENTER);
		textSearch.setColumns(10);
		textSearch.setBounds(126, 370, 154, 20);
		FieldPanel.add(textSearch);
		
		JButton btnNewButton_1_1_1 = new JButton("Checkout");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close();
				Bill b1=new Bill();
				b1.getid(id);
				total=crudrepo.getTotal();
				b1.setField(total);
				b1.loadtable();
				crudrepo.saveOrder(id);
				crudrepo.deleteCART();
				b1.setVisible(true);
				
			}
		});
		btnNewButton_1_1_1.setFocusable(false);
		btnNewButton_1_1_1.setForeground(new Color(0, 0, 128));
		btnNewButton_1_1_1.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnNewButton_1_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1_1.setBounds(258, 537, 120, 31);
		FieldPanel.add(btnNewButton_1_1_1);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchCart();
				loadtableCart();
				PField.setEditable(false);
			}
		});
		btnSearch.setForeground(new Color(75, 0, 130));
		btnSearch.setFont(new Font("Tw Cen MT", Font.BOLD, 19));
		btnSearch.setFocusable(false);
		btnSearch.setBackground(Color.WHITE);
		btnSearch.setBounds(220, 420, 87, 31);
		FieldPanel.add(btnSearch);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		scrollPane_1.setBounds(416, 30, 395, 549);
		contentPane.add(scrollPane_1);
		scrollPane_1.setViewportView(cart);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		scrollPane.setBounds(822, 30, 412, 549);
		contentPane.add(scrollPane);
		
		details = new JTable();
		scrollPane.setViewportView(details);
		
		JLabel lblNewLabel_1 = new JLabel("CART");
		lblNewLabel_1.setBounds(597, 11, 49, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("STOCK");
		lblNewLabel_1_1.setBounds(1007, 11, 49, 14);
		contentPane.add(lblNewLabel_1_1);
	}
	public void AddToCart()
	{
		String pidstr = PField.getText();
		int pid = Integer.parseInt(pidstr);
		String qtystr = Qfield.getText();
		int qty = Integer.parseInt(qtystr);
		Cart crt = new Cart(pid,qty);
		crudrepo.addToCart(crt);
	}
	public void loadtable()
	{
		ResultSet resultSet=crudrepo.getStock();
		details.setModel(DbUtils.resultSetToTableModel(resultSet));
	}
	public void loadtableCart()
	{
		ResultSet resultSet=crudrepo.getCart();
		cart.setModel(DbUtils.resultSetToTableModel(resultSet));
	}
	
	public void searchCart()
	{
		String idstr = textSearch.getText();
		int id = Integer.parseInt(idstr);
		Cart crt = crudrepo.getCart(id);
		PField.setText(String.valueOf(crt.getProduct_no()));
		Qfield.setText(String.valueOf(crt.getQuantity()));
		
	}
	public void updateCart()
	{
		String idstring = PField.getText();
		int id = Integer.parseInt(idstring);
		String qtystr = Qfield.getText();
		int qty = Integer.parseInt(qtystr);
		Cart crt = new Cart(id,qty);
		crudrepo.editCart(crt);
	}
	
	public void deleteCart()
	{
		String idstring = textSearch.getText();
		int id = Integer.parseInt(idstring);
		crudrepo.deleteCART(id);
	}
	public void updateStock()
	{
		String idstring = PField.getText();
		int id = Integer.parseInt(idstring);
		String qtystr = Qfield.getText();
		int qty = Integer.parseInt(qtystr);
		StockDetails stk = new StockDetails(id,qty);
		crudrepo.updateStock2(stk);
	}
	
	public void updateStock_edit()
	{
		String idstring = PField.getText();
		int id = Integer.parseInt(idstring);
		String qtystr = Qfield.getText();
		int qty = Integer.parseInt(qtystr);
		StockDetails stk = new StockDetails(id,qty);
		crudrepo.updateStock3(stk);
	}
	
	public void updateStock_delete()
	{
		String idstring = PField.getText();
		int id = Integer.parseInt(idstring);
		String qtystr = Qfield.getText();
		int qty = Integer.parseInt(qtystr);
		StockDetails stk = new StockDetails(id,qty);
		crudrepo.updateStock4(stk);
	}
	
	public void close()
	{
		WindowEvent closewindow=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closewindow);
	}
	public void getID(int id1)
	{
		id=id1;
	}
}
