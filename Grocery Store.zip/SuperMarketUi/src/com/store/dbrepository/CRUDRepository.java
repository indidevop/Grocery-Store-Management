package com.store.dbrepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.store.entities.AddressDetails;
import com.store.entities.Cart;
import com.store.entities.CustomerDetails;
import com.store.entities.LoginDetails;
import com.store.entities.OrderDetails;
import com.store.entities.StockDetails;
import java.time.LocalDate;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;

import MAIN.Bill;

public class CRUDRepository 
{
	int i=0;
	String cname;
	String finalstr;
	String formattedDate;
	public String addCustomer(CustomerDetails cust, AddressDetails addr, LoginDetails login)
	{
		Connection connection = DBConnection.getConnection();
		String sql1 = "insert into customer_details (customer_name,customer_mail,customer_contact) values(?,?,?)";
		String sql2 = "insert into address_details (customer_address,customer_pincode) values (?,?)";
		String sql3 = "insert into login_details (username,pass) values(?,?)";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql1);
			PreparedStatement pStatement2 = connection.prepareStatement(sql2);
			PreparedStatement pStatement3 = connection.prepareStatement(sql3);
			pStatement1.setString(1, cust.getCustomer_name());
			pStatement1.setString(2, cust.getCustomer_mail());
			pStatement1.setInt(3, cust.getCustomer_contact());
			
			pStatement2.setString(1,addr.getCustomer_address());
			pStatement2.setInt(2,addr.getCustomer_pincode());
			
			pStatement3.setString(1,login.getUsername());
			pStatement3.setString(2,login.getPass());
			
			pStatement1.executeUpdate();
			pStatement2.executeUpdate();
			pStatement3.executeUpdate();
			
			return "Record added!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not added!";
		}
	}
	
	public int getCustomer(String Uname,String Upass)
	{
		int flag=0;
		Connection connection = DBConnection.getConnection();
		String sql5 = "select username,pass,customer_id from login_details where username=? AND pass=?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			
			pStatement1.setString(1,Uname);
			pStatement1.setString(2,Upass);
			ResultSet resultset = pStatement1.executeQuery();
			
			
			if(resultset.next()==true)
			{
				flag=resultset.getInt("customer_id");
			}
			
			return flag;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public String getCustomerName(int id)
	{
		
		Connection connection = DBConnection.getConnection();
		String sql5 = "select customer_name from customer_details where customer_id=?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			
			pStatement1.setInt(1,id);
			
			ResultSet resultset = pStatement1.executeQuery();
			String name=null;
			
			if(resultset.next()==true)
			{
				name=resultset.getString("customer_name");
			}
			return name;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
		
	}
	
	public String getCustomerAddress(int id)
	{
		
		Connection connection = DBConnection.getConnection();
		String sql5 = "select customer_address,customer_pincode from address_details where customer_id=?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			
			pStatement1.setInt(1,id);
			
			ResultSet resultset = pStatement1.executeQuery();
			String address=null;
			int pincode=0;
			
			if(resultset.next()==true)
			{
				address=resultset.getString("customer_address");
				pincode=resultset.getInt("customer_pincode");
				String pinstr = Integer.toString(pincode);
				finalstr = address+" "+pinstr+" "; 
			}
			return finalstr;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
		
	}
	

	
	public ResultSet getStock()
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "select * from stock_details";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			ResultSet resultset = pStatement1.executeQuery();
			return resultset;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public String addStock(StockDetails stk)
	{
		Connection connection = DBConnection.getConnection();
		String sql4="insert into stock_details values(?,?,?,?)";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql4);
			pStatement1.setInt(1, stk.getProduct_no());
			pStatement1.setString(2, stk.getProduct_name());
			pStatement1.setInt(3, stk.getQuantity());
			pStatement1.setInt(4, stk.getPrice_per_kg());
			pStatement1.executeUpdate();
			return "Record Added";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not added!";
		}
		
	}
	
	public String updateStock(StockDetails stk)
	{
		Connection connection = DBConnection.getConnection();
		String sql4="update stock_details set product_no = ?, product_name = ?, quantity = ?, price_per_kg = ? where product_no = ?";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql4);
			pStatement1.setInt(1, stk.getProduct_no());
			pStatement1.setString(2, stk.getProduct_name());
			pStatement1.setInt(3, stk.getQuantity());
			pStatement1.setInt(4, stk.getPrice_per_kg());
			pStatement1.setInt(5, stk.getProduct_no());
			pStatement1.executeUpdate();
			return "Record Updated!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Updated!";
		}
		
	}
	
	public String updateStock2(StockDetails stk)
	{
		Connection connection = DBConnection.getConnection();
		String sql123="select quantity from stock_details where product_no = ?";
		String sql4="update stock_details set quantity = ? where product_no = ?";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql4);
			PreparedStatement pStatement2 = connection.prepareStatement(sql123);
			pStatement2.setInt(1, stk.getProduct_no());
			ResultSet resultset2 = pStatement2.executeQuery();
			int qty=0;
			int newq=0;
			if(resultset2.next())
			{qty= resultset2.getInt("quantity");}
			//For other functions
			i=stk.getQuantity();
			if(qty>=stk.getQuantity())
			{newq=(qty-stk.getQuantity());}
			else
			{
				return "Insufficient stock";
			}
			
			
			pStatement1.setInt(1,newq);
			
			pStatement1.setInt(2, stk.getProduct_no());
			pStatement1.executeUpdate();
			return "Record Updated!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Updated!";
		}
		
	}
	
	public StockDetails getStock(int id)
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "select * from stock_details where product_no = ?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			pStatement1.setInt(1,id);
			ResultSet resultset = pStatement1.executeQuery();
			
			StockDetails stk = null;
			
			if(resultset.next()==true)
			{
				int pid = resultset.getInt(1);
				String name = resultset.getString(2);
				int qty = resultset.getInt(3);
				int price = resultset.getInt(4);
				stk = new StockDetails(pid,name,qty,price);
				return stk;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public String deleteStock(int id)
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "delete from stock_details where product_no = ?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			pStatement1.setInt(1,id);
			pStatement1.executeUpdate();
			return "Record Deleted";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Deleted";
		}
	}
	public ResultSet getCart()
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "select * from cart";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			ResultSet resultset = pStatement1.executeQuery();
			return resultset;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public void addToCart(Cart crt)
	{
		Connection connection = DBConnection.getConnection();
		String sql1 = "select product_name from stock_details where product_no=?";
		String sql2 = "select price_per_kg from stock_details where product_no=?";
		String sql3="insert into cart values(?,?,?,?)";
		
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql1);
			PreparedStatement pStatement2 = connection.prepareStatement(sql2);
			PreparedStatement pStatement3 = connection.prepareStatement(sql3);

			pStatement1.setInt(1,crt.getProduct_no());
			ResultSet resultset1 = pStatement1.executeQuery();
			String name=null;
			int price=0;
			if(resultset1.next())
			{name= resultset1.getString("product_name");}
			
			pStatement2.setInt(1, crt.getProduct_no());			
			ResultSet resultset2 = pStatement2.executeQuery();
			if(resultset2.next())
			{price = resultset2.getInt("price_per_kg");}			
			
			int totalPrice = ((crt.getQuantity())*(price));
			
			pStatement3.setInt(1, crt.getProduct_no());
			pStatement3.setString(2, name);
			pStatement3.setInt(3, crt.getQuantity());
			pStatement3.setInt(4, totalPrice);
			
			pStatement3.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public String editCart(Cart crt)
	{
		Connection connection = DBConnection.getConnection();
		String sql4="update cart set quantity = ? where product_no = ?";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql4);
			
			
			pStatement1.setInt(1, crt.getQuantity());
			
			pStatement1.setInt(2, crt.getProduct_no());
			pStatement1.executeUpdate();
			return "Record Updated!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Updated!";
		}
		
	}
	
	public Cart getCart(int id)
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "select * from cart where product_no = ?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			pStatement1.setInt(1,id);
			ResultSet resultset = pStatement1.executeQuery();
			
			Cart crt = null;
			
			if(resultset.next()==true)
			{
				int pid = resultset.getInt(1);
				int qty = resultset.getInt(3);
				crt = new Cart(pid,qty);
				return crt;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public String deleteCART(int id)
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "delete from cart where product_no = ?";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			pStatement1.setInt(1,id);
			pStatement1.executeUpdate();
			return "Record Deleted";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Deleted";
		}
	}
	
	public String deleteCART()
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "delete from cart";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			pStatement1.executeUpdate();
			return "Record Deleted";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Deleted";
		}
	}
	
	
	public String updateStock3(StockDetails stk)
	{
		Connection connection = DBConnection.getConnection();
		String sql1="update stock_details set quantity = ? where product_no = ?";
		String sql2="select quantity from stock_details where product_no = ?";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql1);
			PreparedStatement pStatement2 = connection.prepareStatement(sql2);
			
			pStatement2.setInt(1, stk.getProduct_no());
			ResultSet resultset2 = pStatement2.executeQuery();
			
			int qty=0;
			int newq=0;
			
			if(resultset2.next())
			{qty= resultset2.getInt("quantity");}
			//For other functions
			
			if(i>stk.getQuantity())
			{newq=(qty+(i-stk.getQuantity()));}
			else
			{
				newq=(qty-(stk.getQuantity()-i));
			}
			i=stk.getQuantity();
			
			pStatement1.setInt(1,newq);
			
			pStatement1.setInt(2, stk.getProduct_no());
			pStatement1.executeUpdate();
			return "Record Updated!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Updated!";
		}
		
	}
	
	public String updateStock4(StockDetails stk)
	{
		Connection connection = DBConnection.getConnection();
		String sql1="update stock_details set quantity = ? where product_no = ?";
		String sql2="select quantity from stock_details where product_no = ?";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql1);
			PreparedStatement pStatement2 = connection.prepareStatement(sql2);
			
			pStatement2.setInt(1, stk.getProduct_no());
			ResultSet resultset2 = pStatement2.executeQuery();
			
			int qty=0;
			int newq=0;
			
			if(resultset2.next())
			{qty= resultset2.getInt("quantity");}
			//For other functions
			
			
			newq=(qty+i);
			
			
			
			pStatement1.setInt(1,newq);
			
			pStatement1.setInt(2, stk.getProduct_no());
			pStatement1.executeUpdate();
			return "Record Updated!";
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Record not Updated!";
		}
		
	}
	
	public int getTotal()
	{
		
		Connection connection = DBConnection.getConnection();
		String sql1="select sum(price) from cart";
		try 
		{
			PreparedStatement pStatement1 = connection.prepareStatement(sql1);			
			ResultSet resultset=pStatement1.executeQuery();
			int total=0;
			if(resultset.next())
			{
				total=resultset.getInt(1);
			}
			return total;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public void saveOrder(int id)
	{
		Connection connection = DBConnection.getConnection();
		String sql = "select * from cart";
		String sql1 = "insert into order_details(customer_id,product_no,product_name,quantity,total_cost,order_date)values(?,?,?,?,?,?)";
		LocalDate dt = java.time.LocalDate.now();
		formattedDate = dt.format(DateTimeFormatter.ofPattern("dd-MMM-yy"));
		
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql);
			PreparedStatement pStatement2 = connection.prepareStatement(sql1);
			ResultSet resultset=pStatement1.executeQuery();
			while(resultset.next())
			{
				int cust_id = id;
				int prod_no = resultset.getInt("product_no");
				String prod_name = resultset.getString("product_name");
				int prod_qty = resultset.getInt("quantity");
				int prod_cost = resultset.getInt("price");
				pStatement2.setInt(1, cust_id);
				pStatement2.setInt(2, prod_no);
				pStatement2.setString(3, prod_name);
				pStatement2.setInt(4, prod_qty);
				pStatement2.setInt(5, prod_cost);
				pStatement2.setString(6, formattedDate);
				pStatement2.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public ResultSet getOrders()
	{
		Connection connection = DBConnection.getConnection();
		String sql5 = "select * from order_details";
		try {
			PreparedStatement pStatement1 = connection.prepareStatement(sql5);
			ResultSet resultset = pStatement1.executeQuery();
			return resultset;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
}