package com.store.entities;

public class AddressDetails 
{
	int customer_id ;
	String customer_address;
	int customer_pincode;
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	public int getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(int customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	public AddressDetails(String customer_address, int customer_pincode) {
		super();
		this.customer_address = customer_address;
		this.customer_pincode = customer_pincode;
	}
	
}