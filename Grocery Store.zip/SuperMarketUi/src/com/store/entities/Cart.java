package com.store.entities;

public class Cart 
{
	int product_no;
	int quantity;
	String product_name;
	int price;
	
	public Cart(int product_no, int quantity, String product_name, int price) {
		super();
		this.product_no = product_no;
		this.quantity = quantity;
		this.product_name = product_name;
		this.price = price;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getProduct_no() {
		return product_no;
	}
	public void setProduct_no(int product_no) {
		this.product_no = product_no;
	}
	

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Cart(int product_no,int quantity) {
		super();
		this.product_no = product_no;
		this.quantity = quantity;
	}
	
}
