package com.store.entities;

public class LoginDetails 
{
	int customer_id;
	private String username; 
	private String pass;

	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public LoginDetails(String username, String pass) {
		super();
		this.username = username;
		this.pass = pass;
	}
}