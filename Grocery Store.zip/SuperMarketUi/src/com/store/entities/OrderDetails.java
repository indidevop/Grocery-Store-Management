package com.store.entities;

public class OrderDetails {
	int customer_id;
	int product_no; 
	String product_name; 
	int quantity; 
	int total_cost; 
	String order_date;
	public OrderDetails(int customer_id, int product_no, String productname, int quantity, int total_cost,
			String order_date) {
		super();
		this.customer_id = customer_id;
		this.product_no = product_no;
		this.product_name = productname;
		this.quantity = quantity;
		this.total_cost = total_cost;
		this.order_date = order_date;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getProduct_no() {
		return product_no;
	}
	public void setProduct_no(int product_no) {
		this.product_no = product_no;
	}
	public String getProductname() {
		return product_name;
	}
	public void setProductname(String productname) {
		this.product_name = productname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(int total_cost) {
		this.total_cost = total_cost;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}


}
