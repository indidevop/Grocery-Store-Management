package com.store.entities;

public class StockDetails {
	
	int product_no; 
	String product_name; 
	int quantity; 
	int price_per_kg;
	public StockDetails(int product_no, String product_name, int quantity, int price_per_kg) {
		super();
		this.product_no = product_no;
		this.product_name = product_name;
		this.quantity = quantity;
		this.price_per_kg = price_per_kg;
	}
	public StockDetails(int product_no, int quantity) {
		super();
		this.product_no = product_no;
		this.quantity = quantity;
	}
	public int getProduct_no() {
		return product_no;
	}
	public void setProduct_no(int product_no) {
		this.product_no = product_no;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice_per_kg() {
		return price_per_kg;
	}
	public void setPrice_per_kg(int price_per_kg) {
		this.price_per_kg = price_per_kg;
	}

}
